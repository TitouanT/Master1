export class Entreprise {
    id: number;
    nom: string;
    adresse: string;
    codePostal: number;
    ville: string;
    pays: string;
    email: string;
}
